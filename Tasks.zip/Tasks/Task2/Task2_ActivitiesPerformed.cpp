#include <iostream>
using namespace std;


void activityselection(int start[], int end[], int n)
{
	
	if (n<1 || n>210 ){
		cout<<"Not in the range. ";
		return;
	}
	
	int i=0, j,count=1;

	for (j = 1; j < n; j++)
	{
	if (start[j] >= end[i])
	{
		count=count+1;
		i = j;
	}
	}
	cout<<"A person can perform activities: "<<count;
}


int main()
{
	int start[] = {1, 3, 2, 5};
	int end[] = {2, 4, 3, 6};
	int n = 4;
	activityselection(start, end, n);
	return 0;
}


