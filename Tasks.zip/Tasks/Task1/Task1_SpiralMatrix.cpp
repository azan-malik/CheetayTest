#include <bits/stdc++.h>
using namespace std;
#define R 4
#define C 4
 
void spiralPrint(int r, int c, int matrix[R][C])
{
    
	if (r<1 || c>100){
	cout<<" Not in the range. ";
	return;
	}
	else{
	
	int i, k = 0, l = 0;
 	
	 while (k < r && l < c) {
     
        for (i = l; i < c; ++i) {
            cout << matrix[k][i] << " ";
        }
        k++;
 
  
        for (i = k; i < r; ++i) {
            cout << matrix[i][c - 1] << " ";
        }
        c--;
 
    
        if (k < r) {
            for (i = c - 1; i >= l; --i) {
                cout << matrix[r - 1][i] << " ";
            }
            r--;
        }
 
      
        if (l < c) {
            for (i = r - 1; i >= k; --i) {
                cout << matrix[i][l] << " ";
            }
            l++;
        }
   	 }
	}
}
 

int main()
{
    int matrix[R][C] = { { 1, 2, 3, 4 },
                    { 5, 6, 7, 8 },
                    { 9, 10, 11, 12}, 
					 { 13, 14, 15, 16}};
     

    spiralPrint(R, C, matrix);
    return 0;
}
