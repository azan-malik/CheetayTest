#include <iostream>
#include <algorithm>
using namespace std;
 

int minMoney(int arr[], int n, int k)
{	
	if(n<1 || n>100000 || k<0 || k>n-1 ){
		cout<<"Out of range. "<<endl;
		return 0;
	}else{
    int minCandy = 0;
    for (int i = 0; i < n; i++) {
        minCandy = minCandy + arr[i];
        n = n - k;
    }
    return minCandy;
	}
}
 
 

int maxMoney(int arr[], int n, int k)
{
	if(n<1 || n>100000 || k<0 || k>n-1 ){
		cout<<"Out of range. "<<endl;
		return 0;
	}
	else{
    int maxCandy= 0, p = 0;
 
    for (int i = n - 1; i >= p; i--)
    {
        maxCandy = maxCandy + arr[i];
        p = p + k;
    }
    return maxCandy;
	}
}
 
int main()
{
    int arr[] = { 3, 2, 1, 4 };
    int n = 4;
    int k = 2;
    sort(arr, arr + n);
 
   
    cout << "Minimum Cost: " <<minMoney(arr, n, k)  << endl
         << "Maximum Cost: " << maxMoney(arr, n, k) << endl;
    return 0;
}
