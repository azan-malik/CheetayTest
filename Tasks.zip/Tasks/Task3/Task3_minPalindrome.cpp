#include <iostream>
using namespace std;

bool isPalindrome(string s, int start, int end)
{
    while (start < end)
    {
        if (s[start++] != s[end--])
            return false;
    }
    return true;
}


void countMin(string s)
{
  int n = s.length();
  if (n<1 || n>103){
  	cout<<"Out of range. ";
  	return;
  }
 
  for (int i = n-1; i >= 0; --i)
  {
    if (isPalindrome(s,0,i))
    {
      cout<<"Minimum characters required to make it palindrome is "<<(n-i-1)<<endl;
      break;
    }
  }
}

int main()
{
  string s = "";
  countMin(s);
}
